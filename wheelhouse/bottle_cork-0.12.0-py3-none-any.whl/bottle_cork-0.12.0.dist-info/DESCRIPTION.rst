Cork is a simple Authentication/Authorization libraryfor the Bottle and Flask web frameworks.


